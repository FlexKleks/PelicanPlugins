<?php

namespace FlexKleks\ServerFolders\Providers;

use Illuminate\Support\ServiceProvider;

class ServerFoldersPluginProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        //
    }
}
