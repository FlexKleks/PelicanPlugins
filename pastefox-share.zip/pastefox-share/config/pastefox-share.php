<?php

return [
    'api_key' => env('PASTEFOX_API_KEY'),
    'visibility' => env('PASTEFOX_VISIBILITY', 'PUBLIC'),
    'effect' => env('PASTEFOX_EFFECT', 'NONE'),
    'theme' => env('PASTEFOX_THEME', 'dark'),
    'password' => env('PASTEFOX_PASSWORD'),
];
